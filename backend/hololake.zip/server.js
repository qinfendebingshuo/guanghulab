require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// 路由引入
const notionRoutes = require('./routes/notion');
const feishuRoutes = require('./routes/feishu');
const routerRoutes = require('./routes/router');

app.use('/notion', notionRoutes);
app.use('/feishu', feishuRoutes);
app.use('/router', routerRoutes);

app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    message: 'HoloLake 后端服务运行中',
    version: '0.2.0',
    routes: ['/notion/test', '/feishu/test', '/router/test', '/router/chat']
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 服务启动成功，端口：${PORT}`);
});
